// =========================
// SAVE STOTRAM WITH REALTIME
// =========================

import {
    collection,
    addDoc,
    serverTimestamp
}
from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const form = document.getElementById("stotramForm");

form.addEventListener("submit", async(e)=>{

    e.preventDefault();

    const title =
    document.getElementById("title").value;

    const category =
    document.getElementById("category").value;

    const image =
    document.getElementById("image").value;

    const description =
    document.getElementById("description").value;

    const content =
    document.getElementById("content").value;

    // AUTO SLUG

    const slug = title
    .toLowerCase()
    .replace(/[^\w ]+/g,'')
    .replace(/ +/g,'-');

    try{

        await addDoc(
            collection(db,"stotrams"),
            {
                title,
                category,
                image,
                description,
                content,
                slug,
                createdAt:serverTimestamp()
            }
        );

        alert("🚩 Stotram Added Successfully");

        form.reset();

    }

    catch(error){

        console.log(error);

        alert(error.message);
    }

});