import { db } from './firebase-config.js';

import {
    collection,
    getDocs,
    query,
    where
}
from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

async function loadStotram(){

    const container =
    document.getElementById("stotramContainer");

    // URL SLUG

    const params =
    new URLSearchParams(window.location.search);

    const slug =
    params.get("slug");

    if(!slug){

        container.innerHTML = `
        <h2>
            ❌ No Slug Found
        </h2>
        `;

        return;
    }

    try{

        // FIREBASE QUERY

        const q =
        query(
            collection(db,"stotrams"),
            where("slug","==",slug)
        );

        const querySnapshot =
        await getDocs(q);

        // NOT FOUND

        if(querySnapshot.empty){

            container.innerHTML = `
            <h2>
                ❌ No Stotram Found
            </h2>
            `;

            return;
        }

        // GET DATA

        querySnapshot.forEach((doc)=>{

            const data = doc.data();

            // FORMAT CONTENT

            const formattedContent =
            data.content
            ?.split('\n')
            .map(line => `<p>${line}</p>`)
            .join('');

            container.innerHTML = `

            <div class="stotram-wrapper">

                <!-- IMAGE SECTION -->

                <div class="image-section">

                    <div class="ram-circle">

                        <div class="chakra-ring"></div>

                        <div class="ram-image">

                            <img
                            src="${data.image || 'images/default.jpg'}"
                            alt="${data.title}">

                        </div>

                        <div class="diya-ring">

                            <span class="diya diya-1">🪔</span>
                            <span class="diya diya-2">🪔</span>
                            <span class="diya diya-3">🪔</span>
                            <span class="diya diya-4">🪔</span>
                            <span class="diya diya-5">🪔</span>
                            <span class="diya diya-6">🪔</span>

                        </div>

                    </div>

                </div>

                <!-- CONTENT SECTION -->

                <div class="content-section">

                    <span class="category-tag">
                        ${data.category || ''}
                    </span>

                    <h1>
                        ${data.title || ''}
                    </h1>

                    <p class="desc">
                        ${data.description || ''}
                    </p>

                    <!-- EXTRA DETAILS -->

                    <div class="extra-info">

                        <div class="info-box">
                            <strong>🧘 Author:</strong>
                            ${data.author || 'Unknown'}
                        </div>

                        <div class="info-box">
                            <strong>🌐 Language:</strong>
                            ${data.language || 'Hindi'}
                        </div>

                        <div class="info-box">
                            <strong>📅 Publish Date:</strong>
                            ${data.publishDate || 'N/A'}
                        </div>

                    </div>

                    <!-- STOTRAM CONTENT -->

                    <div class="stotram-text">

                        ${formattedContent}

                    </div>

                </div>

            </div>

            `;
        });

    }

    catch(error){

        console.log(error);

        container.innerHTML = `
        <h2>
            ❌ Error Loading Stotram
        </h2>
        `;
    }
}

loadStotram();