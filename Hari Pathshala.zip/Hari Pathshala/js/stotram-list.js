import { db } from './firebase-config.js';

import {

    collection,
    getDocs,
    query,
    orderBy

}
from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const container =
document.getElementById("stotramList");

async function loadStotrams(){

    try{

        const q = query(
            collection(db,"stotrams"),
            orderBy("createdAt","desc")
        );

        const snapshot =
        await getDocs(q);

        let html = '';

        snapshot.forEach((doc)=>{

            const data = doc.data();

            html += `

            <div class="stotram-card">

                <div class="card-glow"></div>

                <img
                src="${data.image}"
                alt="${data.title}">

                <div class="card-content">

                    <span class="category-tag">
                        ${data.category}
                    </span>

                    <h2>
                        ${data.title}
                    </h2>

                    <p>
                        ${data.description}
                    </p>

                    <a href="stotram.html?slug=${data.slug}"
                       class="stotram-btn">

                        Read Stotram
                        <i class="fas fa-arrow-right"></i>

                    </a>

                </div>

            </div>

            `;
        });

        container.innerHTML = html;

    }

    catch(error){

        console.log(error);

        container.innerHTML = `

        <h2 style="
            text-align:center;
            color:white;
            padding:40px;
        ">
            ❌ Failed To Load Stotram
        </h2>

        `;
    }
}

loadStotrams();