import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import {
    getFirestore
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
const firebaseConfig = {
    apiKey: "AIzaSyD88JD6WFKJxzt7fRpWwJ_spQ8IynPlZdc",
    authDomain: "hari-pathshala.firebaseapp.com",
    databaseURL: "https://hari-pathshala-default-rtdb.firebaseio.com",
    projectId: "hari-pathshala",
    storageBucket: "hari-pathshala.firebasestorage.app",
    messagingSenderId: "84339431989",
    appId: "1:84339431989:web:dcc0057399254c1edf2f7c",
    measurementId: "G-6N5HZ9Y6PV"
};
const app = initializeApp(firebaseConfig);

const db = getFirestore(app);

export { db };